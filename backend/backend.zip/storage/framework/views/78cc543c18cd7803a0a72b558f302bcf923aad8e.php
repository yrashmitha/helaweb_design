<li class="<?php echo e(Request::is('users*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-edit"></i><span>Users</span></a>
</li>
<li class="<?php echo e(Request::is('projects*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('projects.index')); ?>"><i class="fa fa-edit"></i><span>Projects</span></a>
</li>

<?php /**PATH F:\Helaweb Design\backend\resources\views/layouts/menu.blade.php ENDPATH**/ ?>