<!-- Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control','maxlength' => 191,'maxlength' => 191]); ?>

</div>

<!-- Description Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('description', 'Description:'); ?>

    <?php echo Form::textarea('description', null, ['class' => 'form-control','rows' => 10, 'cols' => 40,'maxlength' => 9999,'maxlength' => 9999]); ?>



</div>

<!-- Url Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('url', 'Url:'); ?>

    <?php echo Form::text('url', null, ['class' => 'form-control','maxlength' => 191,'maxlength' => 191]); ?>

</div>

<!-- Image Path Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('image_path', 'Image Path:'); ?>

    <?php echo Form::file('image_path'); ?>

</div>

<!-- Cover-Path Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('cover-path', 'Cover-Path:'); ?>

    <?php echo Form::file('cover_path'); ?>

    
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH F:\Helaweb Design\backend\resources\views/projects/fields.blade.php ENDPATH**/ ?>