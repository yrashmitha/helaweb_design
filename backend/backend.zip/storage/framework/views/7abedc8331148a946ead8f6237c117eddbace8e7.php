<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($project->name); ?></p>
</div>

<!-- Description Field -->
<div class="form-group">
    <?php echo Form::label('description', 'Description:'); ?>

    <p><?php echo e($project->description); ?></p>
</div>

<!-- Url Field -->
<div class="form-group">
    <?php echo Form::label('url', 'Url:'); ?>

    <p><?php echo e($project->url); ?></p>
</div>

<!-- Image Path Field -->
<div class="form-group">
    <?php echo Form::label('image_path', 'Image Path:'); ?>

    <img src="/storage<?php echo e($project->image); ?>" width="300px" height="300px" alt="">

    <p><?php echo e($project->image_path); ?></p>
</div>

<!-- Cover-Path Field -->
<div class="form-group">
    <?php echo Form::label('cover-path', 'Cover-Path:'); ?>

    <img src="/storage<?php echo e($project->cover); ?>" width="300px" height="300px" alt="">
    <p><?php echo e($project->cover_path); ?></p>
</div>

<?php /**PATH F:\Helaweb Design\backend\resources\views/projects/show_fields.blade.php ENDPATH**/ ?>